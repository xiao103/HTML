<template>
  <nav>
    <router-link to="/">{{ $t('home') }}</router-link>
    <router-link to="/about">{{ $t('about') }}</router-link>
    <router-link to="/contact">{{ $t('contact') }}</router-link>
    <select v-model="locale" @change="changeLocale">
      <option value="zh">中文</option>
      <option value="en">English</option>
    </select>
  </nav>
</template>

<script setup>
import { useI18n } from 'vue-i18n'

const { locale } = useI18n()
const changeLocale = () => {
  localStorage.setItem('lang', locale.value)
}
</script>
