<template>
  <footer>
    <p>&copy; 2025 Iconic Vue</p>
  </footer>
</template>
