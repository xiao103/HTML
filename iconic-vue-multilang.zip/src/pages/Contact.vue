<template>
  <section>
    <h1>{{ $t('contact') }}</h1>
    <p>Contact us via email: contact@example.com</p>
  </section>
</template>
