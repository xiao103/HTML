<template>
  <section>
    <h1>{{ $t('welcome') }}</h1>
  </section>
</template>
