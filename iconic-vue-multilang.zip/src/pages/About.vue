<template>
  <section>
    <h1>{{ $t('about') }}</h1>
    <p>This is a simple About page.</p>
  </section>
</template>
